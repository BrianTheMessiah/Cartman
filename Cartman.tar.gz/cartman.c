/*********************************************************************
 *
 * Copyright (C) 2020-2021 David C. Harrison. All right reserved.
 *
 * You may not use, distribute, publish, or modify this code without 
 * the express written permission of the copyright holder.
 *
 ***********************************************************************/

#include "cartman.h"
#include <semaphore.h>
#include <pthread.h>
#include <unistd.h>
#include <string.h> 
#include <stdio.h>
#include <stdlib.h> 

/*
 * Callback when CART on TRACK arrives at JUNCTION in preparation for
 * crossing a critical section of track.
 */

int tracking = 0; 
int trackCarts = 0; 
sem_t *sems;

struct parts{
	unsigned int cart;
  enum track track;
  enum junction junction;
};

struct parts* definitions(unsigned int cart, enum track track, enum junction junction){
	struct parts* vars = (struct parts *)malloc(sizeof(struct parts));
	vars->cart = cart;
	vars->track = track;
	vars->junction = junction; 
	
	return vars; 
}

void *lockJunc(void *arg){
  int *self = (int *)arg; 

  enum junction startSide; 
  enum junction otherSide; 
  if(self[1] % 2 == 0){
    startSide = (self[1]); 
    otherSide = ((self[1] + 1) % tracking);
  }

  else{
    startSide = ((self[1] + 1) % tracking); 
    otherSide = (self[1]);
  }

  printf("INSIDE lockJunc cart: %d\ttrack: %d\tjunction: %d\t Other Side: %d\n", self[0], self[1], self[2], otherSide);
  
  sem_wait(&sems[startSide]);
  reserve(self[0], startSide);

  sem_wait(&sems[otherSide]); 
  reserve(self[0], otherSide);

  cross(self[0], self[1], self[2]);

  release(self[0], startSide); 
  release(self[0], otherSide); 

  sem_post(&sems[startSide]);
  sem_post(&sems[otherSide]);
  
  free(self);
  pthread_exit(NULL); 
}

struct parts* pieces[35];

void arrive(unsigned int cart, enum track track, enum junction junction) 
{
  printf("INSIDE ARRIVE cart: %d\ttrack: %d\tjunction: %d\n", cart, track, junction);
  pieces[trackCarts] = definitions(cart, track, junction); 

  pthread_t thread;
  pthread_create(&thread, NULL, lockJunc, (void*)pieces[trackCarts]);

  pthread_detach(thread);

  trackCarts += 1; 
  printf("trackCarts %d\n", trackCarts);
}

/*
 * Start the CART Manager. 
 *
 * Return is optional, i.e. entering an infinite loop is allowed, but not
 * recommended. Some implementations will do nothing, most will initialise
 * necessary concurrency primitives.
 */
 
void cartman(unsigned int tracks) 
{
  sems = (sem_t*)malloc(tracks * sizeof(sem_t));
  tracking = tracks; 
  for(long i = 0; i < tracks; i++) 
    sem_init(&sems[i], 0, 1); 
}